import { postcssConfig } from "@repo/tailwind-config/postcss";

export default postcssConfig;
